package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

abstract class Activity_abstract extends AppCompatActivity {
    static int Nombre = 0;
    int Nombre2 = 0;
}